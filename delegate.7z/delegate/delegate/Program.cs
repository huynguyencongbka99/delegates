﻿using System;

/*
 Có thể thấy khi mình khai báo static cho một phương thức, một class thì nó vốn đã
được hình thành. Không cần khai báo nó nữa. Có thể gọi nó ra làm việc luôn
Tuy nhiên nếu nó là một delegate thì vẫn cần phải khai báo nó.
 */

namespace Prog_CSharp
{
    class Prog
    {
        private delegate int TongHaiSo(int a, int b, string s);
        private delegate void LungTung(int x, int y, double z, double t);
        static void Main(string[] args)
        {
            TongHaiSo ac;
            ac = (a, b, c) =>
            {
                int kq;
                kq = a + b;
                return kq;
            };

            LungTung LT;
            LT = (m, n, p, q) =>
            {
                Console.WriteLine($"{m + n} / {p + q}");
            };
            Console.WriteLine($"Tong cua hai so 5 va 6 la: {ac?.Invoke(5, 6, "Con ga")}");
            LT?.Invoke(23, 45, 23.0, 23.4);
            Func<int, int, int> func = (a, b) => { return a + b; };
            Func<int> func2 = () => { return 0; };

            Action<string, int> act = (s, t) =>
            {
                Console.WriteLine($"Ban {s} sinh nam {t}");
            };
            act?.Invoke("Nguyen Cong Huy", 1999);
            Console.WriteLine("I will print zero: {0}", func2?.Invoke());
            List<string> lst = new List<string>();
            lst.Add("Nguyen Cong Huy");
            lst.Add("Nam sinh: 1999");
            lst.Add("Chuyen nganh: Co Dien Tu");
            foreach (var i in lst)
            {
                Console.WriteLine(i);
            }

            Func<int, bool> SoSanh = (a) => { return (a > 1999); };
            Console.WriteLine($"Whether a > 1999 or not? {SoSanh?.Invoke(2000)}");

            Predicate<int> Pre = (a) => { return (a > 1999); };
            Console.WriteLine($"Whether a > 1999 or not2? {Pre?.Invoke(2800)}");
        }
    }
}